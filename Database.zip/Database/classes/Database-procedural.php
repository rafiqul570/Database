<?php

class Connect{
 
 public function connectDB(){
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "blog";
    $con = mysqli_connect($host,$user,$pass,$db);
    return $con;
 }


}
