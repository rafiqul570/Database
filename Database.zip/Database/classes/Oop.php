<?php
spl_autoload_register(function($class_name){
include "classes/".$class_name.".php";
}); 
//error_reporting(0);  

/*
class
*/

class User{

private $db;

  public function __construct(){
    $this->db = new Database();
  }


public function userRegistration($data){
		$name = $data['name'];
		$username = $data['username'];
		$email = $data['email'];
		$password = md5($data['password']);

	if ($name == "" || $username == "" || $email == "" || $password == "" ) {
		    	
	    	$msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'> Error !</span> Field must not be Empty!
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>";
			
		       return $msg; 
		 
	 } 

	 if (strlen($username ) < 3) {
	 	   
			$msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'> Error !</span> Username is too short.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>";
			
		    return $msg;	

	}elseif(preg_match('/[^a-z0-9_-]+/i', $username)) {
			
			$msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
	                    <span class='badge badge-pill badge-success'> Error !</span> Username must only contain alphnumerical, deshes and underscores!
	                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
	                        <span aria-hidden='true'>&times;</span>
	                    </button>
	                </div>"; 

	               return $msg;
	}

	if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
		 	
			 $msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
	                    <span class='badge badge-pill badge-success'> Error !</span> The email address is not valid !
	                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
	                        <span aria-hidden='true'>&times;</span>
	                    </button>
	                </div>"; 
	               return $msg;
		 }

	$query = "SELECT * FROM user WHERE email = '$email' LIMIT 1";
	$chk_email = $this->db->select($query);

	if ($chk_email !== false) {
			 	
	$msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
            <span class='badge badge-pill badge-success'> Error !</span> The email address already Exist!
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                <span aria-hidden='true'>&times;</span>
            </button>
        </div>"; 

        return $msg;
			
	}else{
	
   
   $sql = "INSERT INTO user (name,username,email,password) VALUES ('$name', '$username', '$email', '$password')";
       $result = $this->db->insert($sql);
		
	if ($result) {
			
			    $msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'>Success !</span> Registration Created Successfully Please Login.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>";
			
		    return $msg;
	   
		   
	}else{

     		$msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'> Error !</span> Sorry, Data Not Inserted.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>";
			
		    return $msg;  
	 
	
	   }
	
    } 
 
  }


 //=============LOGIN PATR START===============//

    public function userLogin($data){
	    
		$email = $data['email'];
		$password = md5($data['password']);
		
	   if ($email == "" || $password == "") {	
    	
		      $msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'> Error !</span> Field must not be Empty!
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>";
			
		       return $msg;  
	 
		 }    
   		
 if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
		 	
			$msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'> Error !</span> The email address is not valid.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>";
			
		    return $msg; 
		 
		 
		 }

	$query = "SELECT * FROM user WHERE email = '$email' AND password = '$password' LIMIT 1";
		$result = $this->db->select($query);
        if ($result !== false) {
		 	$value = $result->fetch_assoc();
		 	Session::init();
		  	Session::set("login", true);
		  	Session::set("id", $value['id']);
		  	Session::set("name", $value['name']);
		  	Session::set("username", $value['username']);
		  	Session::set("loginmsg", "<div class='alert alert-success'><strong> Success ! </strong> You are logedin . </div>");
		  	header("Location: index.php");
		 
		 }else{

			$msg = "<div class='alert  alert-success alert-dismissible fade show' role='alert'>
                    <span class='badge badge-pill badge-success'> Error !</span> The email address or password is not valid !
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>";
			
		    return $msg; 
		
		 }
	}

}

?>
