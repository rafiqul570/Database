<?php
 spl_autoload_register(function($class_name){
 include "db/classes/".$class_name.".php";
});

$connect = new Connect();

/*
class
*/
   
class Category{

	 public function insertCategory($data){
            $cat_name  = $data['cat_name'];
            
       if ($cat_name == "" ) {
            
      $msg = '<div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
               <strong>Error !</strong> Field must not be Empty !
              </div>';
      
           return $msg; 
       
     }

    $con = Connect::connectDB();
    $sql = "INSERT INTO category(cat_name)VALUES('$cat_name');";
    $result = mysqli_query($con,$sql);

    if ($result) {

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Success !</strong> Result data Inserte Successfully.
            </div>';
  
       return $msg;
     
       
   }else{

            $msg = '<div class="alert alert-danger alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Error !</strong> Result data Not Inserted.
            </div>';
  
       return $msg; 
       } 
}
    

    public function getCategoryData(){
    	$con = Connect::connectDB();
        $sql = "SELECT *FROM category WHERE post >= 0  ORDER BY cat_id DESC";
        $result = mysqli_query($con,$sql);
         if($result->num_rows > 0){
            return $result;
          } else {
            return false;
          } 
        }
      
     }
